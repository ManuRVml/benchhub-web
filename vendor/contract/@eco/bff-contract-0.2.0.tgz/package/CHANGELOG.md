## 0.2.0 — pre-release

98 operations (0.1.0 as last packed had 97). Additive: no operation was removed or narrowed.

- Added A-05 `POST /api/v1/auth/password-login` (operationId `passwordLogin`), the mock password login of the owner
  decision of 2026-09-28 (it overrides web CF-29 for the mock only; the production target stays OIDC, A-01/A-02).
  - Request (strict): `username` (e-mail, trimmed, at most 254 characters), `password` (1..128 characters).
  - 200: the session cookie and CSRF token are set as after A-02, and the body is the A-04 session
    (`A05Response` has the same shape as `A04Response`, `csrfToken` included).
  - 401 `INVALID_CREDENTIALS` (common ApiError, one generic message for a wrong password and an unknown user);
    400 `BAD_REQUEST` for a malformed body. Public: no session and no CSRF token; the rate limit applies.
- C-33 `sendAssistantMessage`: the documented SSE event schema (`C33Response`) is the CF-111 union
  `token { content } | citation { content } | done { messageId } | error { errorCode }`, the events the mock streams.
  It replaces the single `{ type, content }` event; the last 0.1.0 pack already carried the union, which its changelog
  entry never stated.
